import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from "typeorm";
import { Product } from "./product.model";
import { Template } from "./template.model";

@Entity()
export class TemplateSlot {
    @PrimaryGeneratedColumn()
    id!: number;

    @ManyToOne(() => Template, (template) => template.templateSlots)
    template!: Template;

    @ManyToOne(() => Product, (product) => product.templateSlots, { nullable: true })
    product!: Product | null;

    @Column()
    position!: number;

    @Column()
    width!: number;
}
