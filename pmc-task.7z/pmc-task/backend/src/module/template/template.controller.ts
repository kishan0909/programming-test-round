import { Request, Response } from 'express';
import {getTemplates, allocateProducts} from './template.service';

export const getAllTemplates = async (req: Request, res: Response) => {
 try {
   const templates = await getTemplates();
   res.json(templates);
 } catch (error) {
   res.status(500).json({ error: 'Failed to fetch templates' });
 }
};

export const allocatedProducts = async (req: Request, res: Response) => {
 try {
   const allocation = await allocateProducts();
   res.json(allocation);
 } catch (error) {
   res.status(500).json({ error: 'Allocation failed' });
 }
};