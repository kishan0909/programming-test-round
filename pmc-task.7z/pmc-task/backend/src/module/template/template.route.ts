import { Router } from 'express';
import { getAllTemplates, allocatedProducts } from './template.controller';

const router = Router();

router.get('/', getAllTemplates);
router.post('/allocate', allocatedProducts);

export default router;