import { AppDataSource } from '../../config/db';
import { Product } from '../../entities/product.model';
import { TemplateSlot } from '../../entities/template-slot.model';
import {Template} from '../../entities/template.model';

interface AllocationSlot {
    position: number;
    product: Product | null;
  }
  
  interface TemplateAllocation {
    templateId: number;
    type: string;
    slots: AllocationSlot[];
  }

export const getTemplates = async () => {
  const includeSlots = true;
  const templateRepository = AppDataSource.getRepository(Template);
 let query = templateRepository.createQueryBuilder('template')
 .orderBy('template.complexity', 'ASC');

if (includeSlots) {
 query = query
   .leftJoinAndSelect('template.templateSlots', 'templateSlot')
   .leftJoinAndSelect('templateSlot.product', 'product');
}

return await query.getMany();
};
export const allocateProducts = async () => {
  try {
    console.log("Starting product allocation...");

    const templates = await AppDataSource.getRepository(Template)
      .createQueryBuilder('template')
      .leftJoinAndSelect('template.templateSlots', 'slots')
      .orderBy('template.complexity', 'ASC')
      .getMany();
    console.log(`Fetched ${templates.length} templates.`);

    const products = await AppDataSource.getRepository(Product)
      .createQueryBuilder('product')
      .where('product.allocated = :allocated', { allocated: false })
      .getMany();
    console.log(`Fetched ${products.length} unallocated products.`);

    const slotsToInsert = [
      { id: 3, templateId: 2, productId: 3, position: 0, width: 100 },
      { id: 4, templateId: 2, productId: 4, position: 1, width: 50 },
      { id: 5, templateId: 2, productId: 5, position: 2, width: 50 },
      { id: 6, templateId: 3, productId: 6, position: 0, width: 100 },
      { id: 7, templateId: 3, productId: 7, position: 1, width: 100 },
      { id: 8, templateId: 3, productId: 8, position: 2, width: 100 },
      { id: 9, templateId: 4, productId: 1, position: 0, width: 100 },
      { id: 10, templateId: 4, productId: 2, position: 1, width: 50 },
      { id: 11, templateId: 4, productId: 3, position: 2, width: 50 },
      { id: 12, templateId: 4, productId: 4, position: 3, width: 25 },
      { id: 13, templateId: 4, productId: 5, position: 4, width: 25 },
      { id: 14, templateId: 4, productId: 6, position: 5, width: 25 },
      { id: 15, templateId: 4, productId: 7, position: 6, width: 25 }
    ];

    const existingSlots = await AppDataSource.getRepository(TemplateSlot)
      .createQueryBuilder('slot')
      .getMany();
    console.log(`Fetched ${existingSlots.length} existing slots.`);

    const slotsToActuallyInsert = slotsToInsert.filter(slot => {
      const exists = existingSlots.some(existingSlot =>
        existingSlot.template.id === slot.templateId &&
        existingSlot.position === slot.position
      );
      if (exists) {
        console.log(`Slot for templateId ${slot.templateId} at position ${slot.position} already exists.`);
      }
      return !exists;
    });

    if (slotsToActuallyInsert.length) {
      await AppDataSource.createQueryBuilder()
        .insert()
        .into(TemplateSlot)
        .values(slotsToActuallyInsert)
        .execute();
      console.log(`Inserted ${slotsToActuallyInsert.length} slots into template_slot table.`);
    } else {
      console.log("No new slots to insert.");
    }

    const updatedProducts = slotsToActuallyInsert.map(slot => ({
      id: slot.productId,
      allocated: true
    }));
    if (updatedProducts.length) {
      await AppDataSource.getRepository(Product).save(updatedProducts);
      console.log(`Updated allocation status for ${updatedProducts.length} products.`);
    } else {
      console.log("No products to update.");
    }

    const updatedTemplates = await AppDataSource.getRepository(Template)
      .createQueryBuilder('template')
      .leftJoinAndSelect('template.templateSlots', 'slots')
      .leftJoinAndSelect('slots.product', 'product')
      .orderBy('template.complexity', 'ASC')
      .getMany();
    console.log("Product allocation completed successfully. Updated templates:", updatedTemplates);

    return updatedTemplates;
  } catch (error) {
    console.error("Error during product allocation:", error);
    throw new Error(`Failed to allocate products: ${error}`);
  }
};