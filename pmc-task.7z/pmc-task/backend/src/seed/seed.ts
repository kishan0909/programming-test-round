import { DataSource } from "typeorm";
import { Product } from "../entities/product.model";
import { TemplateSlot } from "../entities/template-slot.model";
import { Template } from "../entities/template.model";

const seedDatabase = async () => {
const AppDataSource = new DataSource({
      type: "postgres",
      host: "localhost",
      port: 5433,
      username: "postgres",
      password: "admin@123",
      database: "template_allocator",
      synchronize: true,
      logging: true,
      entities: [Template, Product,TemplateSlot],
  })

  // Insert products
  const products = [
    { id: 1, name: 'Product A', type: 'Type 1', allocated: false },
    { id: 2, name: 'Product B', type: 'Type 1', allocated: false },
    { id: 3, name: 'Product C', type: 'Type 2', allocated: false },
    { id: 4, name: 'Product D', type: 'Type 3', allocated: false },
    { id: 5, name: 'Product E', type: 'Type 3', allocated: false },
    { id: 6, name: 'Product F', type: 'Type 4', allocated: false },
    { id: 7, name: 'Product G', type: 'Type 4', allocated: false },
    { id: 8, name: 'Product H', type: 'Type 4', allocated: false }
  ];

  await AppDataSource.getRepository(Product).save(products);
  console.log('Inserted products.');

  // Insert templates
  const templates = [
    { id: 1, type: '1:1', slots: 2, complexity: 1 },
    { id: 2, type: '1:2', slots: 3, complexity: 2 },
    { id: 3, type: '1:1:1', slots: 3, complexity: 2 },
    { id: 4, type: '1:2:4', slots: 7, complexity: 3 }
  ];

  await AppDataSource.getRepository(Template).save(templates);
  console.log('Inserted templates.');

  // Insert template slots
  const templateSlots = [
    { id: 3, templateId: 2, productId: 3, position: 0, width: 100 },
    { id: 4, templateId: 2, productId: 4, position: 1, width: 50 },
    { id: 5, templateId: 2, productId: 5, position: 2, width: 50 },
    { id: 6, templateId: 3, productId: 6, position: 0, width: 100 },
    { id: 7, templateId: 3, productId: 7, position: 1, width: 100 },
    { id: 8, templateId: 3, productId: 8, position: 2, width: 100 },
    { id: 9, templateId: 4, productId: 1, position: 0, width: 100 },
    { id: 10, templateId: 4, productId: 2, position: 1, width: 50 },
    { id: 11, templateId: 4, productId: 3, position: 2, width: 50 },
    { id: 12, templateId: 4, productId: 4, position: 3, width: 25 },
    { id: 13, templateId: 4, productId: 5, position: 4, width: 25 },
    { id: 14, templateId: 4, productId: 6, position: 5, width: 25 },
    { id: 15, templateId: 4, productId: 7, position: 6, width: 25 }
  ];

  await AppDataSource.getRepository(TemplateSlot).save(templateSlots);
  console.log('Inserted template slots.');

  await AppDataSource.destroy();
};

seedDatabase().catch((error) => {
  console.error('Error seeding database:', error);
});