import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import TemplateViewer from './components/TemplateViewer';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TemplateViewer />
    </QueryClientProvider>
  );
}

export default App;