import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getTemplates, allocateProducts } from '../service/api.service';

const TemplateViewer = () => {
  const queryClient = useQueryClient();
  
  const { data: templates } = useQuery({
    queryKey: ['templates'],
    queryFn: getTemplates
  });
  
  const allocateMutation = useMutation({
    mutationFn: allocateProducts,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['templates'] });
    }
  });

  const getTemplateLayout = (type: string) => {
    switch(type) {
      case '1:1':
        return 'grid grid-rows-2';
      case '1:2':
        return 'grid grid-rows-[1fr_2fr] grid-cols-[repeat(2,1fr)]';
      case '1:1:1':
        return 'grid grid-rows-3';
      case '1:2:4':
        return 'grid grid-rows-[1fr_1fr_2fr] grid-cols-[repeat(4,1fr)]';
      default:
        return '';
    }
  };

  const renderSlot = (slot: any, idx: number) => (
    <div 
      key={idx} 
      className="border p-4 flex flex-col items-center justify-center min-h-[100px] bg-gray-800"
    >
      {slot.product ? (
        <>
          <div className="font-bold">{slot.product.name}</div>
          {slot.product.type && (
            <div className="text-sm text-gray-400">{slot.product.type}</div>
          )}
        </>
      ) : (
        <div className="text-gray-500">Empty Slot</div>
      )}
    </div>
  );

  return (
    <div className="p-4 bg-gray-900 text-white">
      <button 
        onClick={() => allocateMutation.mutate()}
        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded mb-6"
      >
        Allocate Products
      </button>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates?.data?.map((template: any) => (
          <div key={template.id} className="border rounded-lg p-4">
            <h3 className="text-xl mb-3">Template {template.type}</h3>
            <div className={`${getTemplateLayout(template.type)} gap-2`}>
              {template.templateSlots?.map((slot: any, idx: number) => 
                renderSlot(slot, idx)
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TemplateViewer;