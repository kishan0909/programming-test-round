import { DataSource } from "typeorm"
import { Template } from "../entities/template.model";
import { Product } from "../entities/product.model";
import { TemplateSlot } from "../entities/template-slot.model";

export const AppDataSource = new DataSource({
    type: "postgres",
    host: "localhost",
    port: 5433,
    username: "postgres",
    password: "admin@123",
    database: "template_allocator",
    synchronize: true,
    logging: true,
    entities: [Template, Product,TemplateSlot],
})