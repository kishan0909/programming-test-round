import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { TemplateSlot } from "./template-slot.model";

@Entity()
export class Product {
    @PrimaryGeneratedColumn()
    id!: number;

    @Column()
    name!: string;

    @Column({ nullable: true })
    type!: string;

    @Column({ default: false })
    allocated!: boolean;

    @OneToMany(() => TemplateSlot, (slot) => slot.product)
    templateSlots!: TemplateSlot[]; // Optional for reverse querying
}
