import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from "typeorm";
import { TemplateSlot } from "./template-slot.model";

@Entity()
export class Template {
    @PrimaryGeneratedColumn()
    id!: number;

    @Column()
    type!: string;

    @Column()
    complexity!: number;

    @OneToMany(() => TemplateSlot, (slot) => slot.template, { cascade: true })
    templateSlots!: TemplateSlot[];
}
