import { Request, Response } from 'express';
import { AppDataSource } from '../../config/db';
import { Product } from '../../entities/product.model';

export const getProducts = async (req: Request, res: Response) => {
  try {
    const products = await AppDataSource.getRepository(Product).find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching products' });
  }
};

export const createProduct = async (req: Request, res: Response) => {
  try {
    const product = AppDataSource.getRepository(Product).create(req.body);
    const result = await AppDataSource.getRepository(Product).save(product);
    res.json(result);
  } catch (error) {
    res.status(500).json({ message: 'Error creating product' });
  }
};