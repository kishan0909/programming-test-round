import { AppDataSource } from '../../config/db';
import { Product } from '../../entities/product.model';
import { TemplateSlot } from '../../entities/template-slot.model';
import {Template} from '../../entities/template.model';

interface AllocationSlot {
    position: number;
    product: Product | null;
  }
  
  interface TemplateAllocation {
    templateId: number;
    type: string;
    slots: AllocationSlot[];
  }

export const getTemplates = async () => {
  const includeSlots = true;
  const templateRepository = AppDataSource.getRepository(Template);
 let query = templateRepository.createQueryBuilder('template')
 .orderBy('template.complexity', 'ASC');

if (includeSlots) {
 query = query
   .leftJoinAndSelect('template.templateSlots', 'templateSlot')
   .leftJoinAndSelect('templateSlot.product', 'product');
}

return await query.getMany();
};

export const allocateProducts = async () => {
  const queryRunner = AppDataSource.createQueryRunner();
  await queryRunner.connect();
  await queryRunner.startTransaction();

  try {
    // Get templates ordered by complexity
    const templates = await queryRunner.manager
      .createQueryBuilder(Template, 'template')
      .leftJoinAndSelect('template.templateSlots', 'slots')
      .orderBy('template.complexity', 'ASC')
      .getMany();

    // Get unallocated products
    const products = await queryRunner.manager
      .createQueryBuilder(Product, 'product')
      .where('product.allocated = :allocated', { allocated: false })
      .orderBy('product.id', 'ASC')
      .getMany();

    let productIndex = 0;
    const allocations = [];

    // Allocate products to templates
    for (const template of templates) {
      const slotCount = getTemplateSlotCount(template.type);
      
      for (let position = 0; position < slotCount; position++) {
        const width = getSlotWidth(template.type, position);
        
        if (productIndex < products.length) {
          const product = products[productIndex];
          
          allocations.push({
            template: template,
            product: product,
            position: position,
            width: width
          });
          
          productIndex++;
        }
      }
    }

    // Create template slots
    if (allocations.length > 0) {
      await queryRunner.manager.save(TemplateSlot, allocations);
      
      // Update product allocation status
      const productIds = allocations.map(a => a.product.id);
      await queryRunner.manager
        .createQueryBuilder()
        .update(Product)
        .set({ allocated: true })
        .whereInIds(productIds)
        .execute();
    }

    await queryRunner.commitTransaction();

    return await queryRunner.manager
      .createQueryBuilder(Template, 'template')
      .leftJoinAndSelect('template.templateSlots', 'slots')
      .leftJoinAndSelect('slots.product', 'product')
      .orderBy('template.complexity', 'ASC')
      .getMany();

  } catch (error) {
    await queryRunner.rollbackTransaction();
    throw error;
  } finally {
    await queryRunner.release();
  }
};

function getTemplateSlotCount(type: string): number {
  switch (type) {
    case '1:1': return 2;
    case '1:2': return 3;
    case '1:1:1': return 3;
    case '1:2:4': return 7;
    default: return 0;
  }
}

function getSlotWidth(type: string, position: number): number {
  switch (type) {
    case '1:1':
    case '1:1:1':
      return 100;
    case '1:2':
      return position === 0 ? 100 : 50;
    case '1:2:4':
      if (position === 0) return 100;
      if (position === 1 || position === 2) return 50;
      return 25;
    default:
      return 100;
  }
}