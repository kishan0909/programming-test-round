import { DataSource } from 'typeorm';
import { Product } from '../entities/product.model';
import { TemplateSlot } from '../entities/template-slot.model';
import { Template } from '../entities/template.model';

export const seedData = async () => {
  const AppDataSource = new DataSource({
      type: "postgres",
      host: "localhost",
      port: 5433,
      username: "postgres",
      password: "admin@123",
      database: "template_allocator",
      synchronize: true,
      logging: true,
      entities: [Template, Product,TemplateSlot],
  })
  await AppDataSource.initialize();
  
  // Templates
  const templates = [
    { type: '1:1', complexity: 1 },
    { type: '1:2', complexity: 2 },
    { type: '1:1:1', complexity: 3 },
    { type: '1:2:4', complexity: 4 }
  ];

  // Products
  const products = [
    { name: 'Product 1', type: 'Electronics' },
    { name: 'Product 2', type: 'Clothing' },
    { name: 'Product 3', type: 'Books' },
    { name: 'Product 4', type: 'Electronics' },
    { name: 'Product 5', type: 'Clothing' },
    { name: 'Product 6', type: 'Books' },
    { name: 'Product 7', type: 'Electronics' },
    { name: 'Product 8', type: 'Clothing' },
    { name: 'Product 9', type: 'Books' },
    { name: 'Product 10', type: 'Electronics' },
    { name: 'Product 11', type: 'Books' },
    { name: 'Product 12', type: 'Electronics' },
    { name: 'Product 13', type: 'Clothing' },
    { name: 'Product 14', type: 'Electronics' },
    { name: 'Product 15', type: 'Clothing' }
  ];

  try {
    await AppDataSource.manager.save(Template, templates);
    await AppDataSource.manager.save(Product, products);
    console.log('Seed data inserted successfully');
  } catch (error) {
    console.error('Error seeding data:', error);
  }
};

// Run seeder
seedData();