import express from 'express';
import cors from 'cors';
import { AppDataSource } from './config/db';
import templateRouter from './module/template/template.route';
import productRouter from './module/product/product.route';

const app = express();

app.use(cors());
app.use(express.json());
app.use('/api/templates', templateRouter);
app.use('/api/products', productRouter);

AppDataSource.initialize()
    .then(() => {
        app.listen(7000, () => console.log('Server running on port 7000'));
    })
    .catch((error) => console.log(error));