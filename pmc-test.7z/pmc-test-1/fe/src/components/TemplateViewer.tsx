import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getTemplates, allocateProducts } from '../service/api.service';
import { 
  Button,
  Card,
  CardContent,
  Typography,
  Grid,
  Box,
  CircularProgress
} from '@mui/material';

const TemplateViewer = () => {
  const { data: response, isLoading } = useQuery({
    queryKey: ['templates'],
    queryFn: getTemplates
  });
  
  const queryClient = useQueryClient();
  const allocateMutation:any = useMutation({
    mutationFn: allocateProducts,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['templates'] });
    }
  });

  const getTemplateStyle = (type:any) => {
    const baseStyle = {
      display: 'grid',
      gap: 2,
      height: '400px'
    };

    switch(type) {
      case '1:1':
        return { ...baseStyle, gridTemplateRows: 'repeat(2, 1fr)' };
      case '1:2':
        return { ...baseStyle, gridTemplateRows: '1fr 2fr' };
      case '1:1:1':
        return { ...baseStyle, gridTemplateRows: 'repeat(3, 1fr)' };
      case '1:2:4':
        return { ...baseStyle, gridTemplateRows: '1fr 1fr 1fr' };
      default:
        return baseStyle;
    }
  };

  const getSlotStyle = (template:any, position:any) => {
    const baseStyle = {
      backgroundColor: '#f5f5f5',
      padding: 2,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '2px solid #e0e0e0',
      borderRadius: 1
    };

    if (template.type === '1:2' && position > 0) {
      return { ...baseStyle, gridColumn: 'span 2' };
    }
    if (template.type === '1:2:4') {
      if (position === 0) return { ...baseStyle, gridColumn: 'span 4' };
      if (position === 1 || position === 2) return { ...baseStyle, gridColumn: 'span 2' };
      return { ...baseStyle, gridColumn: 'span 1' };
    }
    return { ...baseStyle, gridColumn: 'span 4' };
  };

  const renderSlot = (template:any, slot:any) => (
    <Box key={slot.position} sx={getSlotStyle(template, slot.position)}>
      {slot.product ? (
        <Box textAlign="center">
          <Typography variant="h6">Product {slot.product.id}</Typography>
          {slot.product.type && (
            <Typography variant="body2" color="text.secondary">
              {slot.product.type}
            </Typography>
          )}
        </Box>
      ) : (
        <Typography color="text.secondary">Empty Slot</Typography>
      )}
    </Box>
  );

  if (isLoading) {
    return (
      <Box display="flex" justifyContent="center" p={4}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box p={3} maxWidth="lg" mx="auto">
      <Box mb={3}>
        <Button 
          variant="contained"
          onClick={() => allocateMutation.mutate()}
          disabled={allocateMutation.isLoading}
        >
          {allocateMutation.isLoading ? 'Allocating...' : 'Allocate Products'}
        </Button>
      </Box>

      <Grid container spacing={3}>
        {response?.data.map((template:any) => (
          <Grid item xs={12} md={6} key={template.id}>
            <Card>
              <CardContent>
                <Typography variant="h5" gutterBottom>
                  Template {template.type}
                </Typography>
                <Box sx={getTemplateStyle(template.type)}>
                  {template.templateSlots?.map((slot:any) => renderSlot(template, slot))}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default TemplateViewer;