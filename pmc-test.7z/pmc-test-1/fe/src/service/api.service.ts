import axios from 'axios';
import { AxiosResponse } from 'axios';
import { AllocationResult, Template } from '../types';

const api = axios.create({
    baseURL: 'http://localhost:7000/api'
  });
  

export const getTemplates = (): Promise<AxiosResponse<Template[]>> => api.get('/templates');
export const allocateProducts = (): Promise<AxiosResponse<AllocationResult[]>> => api.post('/templates/allocate');
export const getProducts = () => api.get('/products');