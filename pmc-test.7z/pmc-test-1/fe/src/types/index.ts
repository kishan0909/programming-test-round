// src/types/index.ts
export interface Product {
    id: number;
    name: string;
    type?: string;
    allocated: boolean;
  }
  
  export interface Template {
    id: number;
    type: string;
    slots: number;
    complexity: number;
  }
  
  export interface AllocationSlot {
    position: number;
    product: Product | null;
  }
  
  export interface AllocationResult {
    templateId: number;
    type: string;
    slots: AllocationSlot[];
  }
  